function S = Source(Q, x, y)
    global g Nx Ny x y hb;
    h = squeeze(Q(1,:,:));  % water depth
    
    % Assuming some bottom topography, define hb(x,y) as needed.
   

    % sin function
%     hb = ones(Nx,Ny);
%     
%     for j=1:Ny
%     hb(:,j) = hb(:,j).*0.1.*sin(4.*x)'+0.1; 
%     end

 % Example: a step before the wall
    hb = ones(Nx,Ny)*0.0;
    hb(round(size(hb, 1) / (2)):end ,1:end) = 0.00;

    plot(x,hb(:,1))
%     plot(x,dhb_dx(1,:))

      % Gradients of the topography
    [dhb_dx, dhb_dy] = gradient(hb', x(2) - x(1), y(2) - y(1));  % central differences
    
    % Source term for each component of Q
    S = zeros(size(Q));
    S(2,:,:) = -g * h .* dhb_dx';  % Source term in x-direction (momentum)
    S(3,:,:) = -g * h .* dhb_dy';  % Source term in y-direction (momentum)
end
