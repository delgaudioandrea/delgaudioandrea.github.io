MUSCL2D - 2D Shallow Water Equations solver (MATLAB)
Author: Andrea Del Gaudio

Second-order finite-volume solver for the 2D shallow water equations:
 - MUSCL-Hancock reconstruction (second order in space and time) with minmod slope limiter
 - Rusanov (local Lax-Friedrichs) numerical flux at cell interfaces
 - Adaptive time step from the CFL condition
 - Bed friction with the Blasius friction factor, computed from the local Reynolds number
 - Wet/dry treatment with a minimum depth threshold
 - Reflective (wall) boundary conditions

HOW TO RUN THE EXAMPLE
 1. Unzip the folder and set it as the MATLAB current folder.
 2. Run MUSCL_SWE_2D.m

The built-in example is a dam-break wave (initial depth h0 = 0.2 m) propagating over
a smooth, flat, dry bed. The script plots the friction term, the free surface and the
velocity during the run, and at the end compares them with the reference solution
stored in h0_SM_T.txt, fr0_SM_T.txt and u0_SM_T.txt (see validation.png).

Main parameters (top of MUSCL_SWE_2D.m):
 - h0           initial water depth behind the dam
 - tend_dimless final dimensionless time t/sqrt(h0/g) (multiples of 0.7, up to 14,
                to match the reference data)
 - Nx, Ny       number of cells in x and y
 - CFL          Courant number

Initial conditions are set in Q0.m, the friction model in Friction.m.
