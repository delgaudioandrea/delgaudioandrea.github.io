% Rusanov numerical flux in the y-direction

function Gnum = Rusanovy(QL,QR,lambdaL,lambdaR)
s = max(abs([lambdaL;lambdaR]));
Gnum = 0.5*(G(QR)+G(QL))-0.5*s*(QR-QL);
end