function fr = Friction(Q, x, y)
    global g Nx Ny x y nu Re h u v; %blend_factor;    
%     % Water depth and velocities
%     h = squeeze(Q(1,:,:));  % Water depth
%     u = squeeze(Q(2,:,:)) ./ h;  % Velocity in x-direction
%     v = squeeze(Q(3,:,:)) ./ h;  % Velocity in y-direction
% 
%     % Compute the Reynolds number
%     Re = (h .* sqrt(u.^2 + v.^2)) / nu;
    
    % Compute the Blasius friction coefficient
    C_f = 0.316./ (Re .^ 0.25);
    %C_f = C_f .*blend_factor;
    %C_f = C_f.*non_dry_mask;

    % Source term for each component of Q
    fr = zeros(size(Q));
    
    % Source term in the x and y direction (momentum equations)
    fr(2,:,:) = - (C_f ./ 8) .* u .* sqrt(u.^2 + v.^2);  % Source in x-direction
    fr(3,:,:) = - (C_f ./ 8) .* v .* sqrt(u.^2 + v.^2);  % Source in y-direction
end