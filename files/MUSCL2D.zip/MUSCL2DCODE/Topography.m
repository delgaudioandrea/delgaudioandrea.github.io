function z = Topography(hb, x, y)
global g Nx Ny x y;
 hb = ones(Nx,Ny)*0.0;
 hb(1:end, round(size(hb, 2) / (1.2)):end) = 0.05;
 z = Hh;
end
