% Physical fluxes for the 2D SWE in the Y direction
function flux_y = G(Q)
global g
flux_y = zeros(size(Q));
flux_y(1,:,:) = Q(3,:,:);
flux_y(2,:,:) = Q(2,:,:).*Q(3,:,:)./Q(1,:,:);
flux_y(3,:,:) = Q(3,:,:).^2./Q(1,:,:)+0.5*g*Q(1,:,:).^2;
end