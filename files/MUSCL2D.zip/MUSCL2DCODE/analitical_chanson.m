%% analitica Chanson
function [X,h_ch] = analitical_chanson(h0, g, mi, ro, Tend, nx, f, T, tw)
global tend
h0= 0.2; % altezza iniziale [m]
g = 9.81; % gravità [m/s^2]
mi= 10*10^-4; % [Pa*s]
ro= 1000; % [kg/m^3]
ni= mi/ro; %[m/s^2]
Tend = 0.2; % tempo finale [s]
nt = 20; 
T = linspace(0,Tend,nt); % tempo [s]
U= 2*(g*h0)^(0.5); %celerità di propagazione del fronte [m/s]
U_mezz= -2*(g*h0*4/9)^0.5+U; %velocità in mezzeria [m/s]
nx=100;
Re= (U_mezz*h0*4/9)/(0.05*ni) % Reynolds number in mezzeria
%f = 0.1*(100/Re)^(1/4); %friction factor [-]
tw= 5; % bed shear stress from simulation in the tip region [Pa]
f = 8*tw/(ro*U^2); %friction factor [-]

for j=1:length(T)
L = 2*T(j)*(g*h0)^(0.5); % lunghezza finale [m]
l=-1.*T(j)*(g*h0)^(0.5);
fun= @(u) (8/(3*f))*((1-((0.5*u)/((g*h0)^(0.5))))/((u^2)/(g*h0)))-((g/h0)^(0.5)).*T(j); %soluzione della celerità
u=fzero(fun,0.0001); %celerità [m/s]
xs= h0*(1.5*(u/((g*h0)^(0.5)))-1)*((g/h0)^(0.5)).*(T(j))+h0*4*((1/(f*((u^2)/(g*h0))))*(1-(0.5*(u/((g*h0)^(0.5)))))^(4));
xf(j,1)= xs
X = linspace(0,xs,xs*1000); % spazio [m]
    for i=1:length(X)
        if X(i)<=((3/2)*(u/((g*h0)^(0.5)))-1)*((g*h0)^(0.5))*T(j)
h_ch(j,i)= h0.*((2/3)-X(i)./(3.*T(j).*(g*h0)^(0.5))).^2;
        else
h_ch(j,i)= h0.*(((f/4)*((u^2)/(g*h0)).*((xs-X(i))./(h0))).^(0.5));
Re = mean(4*h_ch(j,:))*u/ni;
f  = 0.316./ (8*Re .^ 0.25);
        end        
    end

end
end



% 
% 
% for i=1:38
% plot((X),h_ch(i+1,:),'--k','DisplayName','Chanson 2012,  f = 8*t_{wcase0}/(\roU^{(1/4)});')
% axis([0 1 0 0.2])
% legend
% xlabel('x/h0 [-]'); ylabel('z/h0 [-]');
% pause
% clf
% end