function Q = Q0(Q,x,y)
global Nx Ny h0;

% for i = 1:Nx
%     for j=1:Ny
%         r = sqrt( (x(i)-0.75)^2 + (y(j)+0.75)^2);
%         if (r<0.5)
%             Q(:,i,j) = [2; 0; 0];
%         else
%             Q(:,i,j) = [0.5; 0; 0];
%         end
%     end
% end
% 
% for i = 1:Nx
%     for j=1:Ny
%         r = sqrt( (x(i)-0.75)^2 + (y(j)-0.75)^2);
%         if (r<0.5)
%             Q(:,i,j) = Q(:,i,j)+[2; 0; 0];
%         else
%             Q(:,i,j) = Q(:,i,j)+[0.5; 0; 0];
%         end
%     end
% end

% rectangular dam break
h0=0.2;
for i = 1:Nx
    for j=1:Ny
        if (x(i)<0.0)
            Q(:,i,j) = [h0; 0; 0];
        else
            Q(:,i,j) = [0.000000001; 0; 0];
        end
    end
end
end