% Rusanov numerical flux in the x-direction

function Fnum = Rusanovx(QL,QR,lambdaL,lambdaR)
s = max(abs([lambdaL;lambdaR]));
Fnum = 0.5*(F(QR)+F(QL))-0.5*s*(QR-QL);
end