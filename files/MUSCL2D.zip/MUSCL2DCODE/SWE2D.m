% scheme for the 2D SWE
% with the HLL(Rusanov numerical flux)

clear;
global g Nx Ny;
% Physical parameters
g = 9.81; 
xL = -1; xR = 1;
yL = -1; yR = 1;
t = 0;
tend = 1;

% Computational paramters
Nx = 64;
Ny = 64;
dx = (xR - xL)/Nx;
dy = (yR - yL)/Ny;
x = linspace(xL +dx/2,xR-dx/2,Nx);
y = linspace(yL +dy/2,yR-dy/2,Ny);
CFL = 0.9;

% initial data
Q = zeros(3,Nx,Ny);
Q = Q0(Q,x,y);
Qnew = Q;

%plot
surf(x,y,squeeze(Q(1,:,:))','EdgeColor','none','FaceColor','interp')
axis([xL xR yL yR 0 3])
light('Position', [-3 -1 1],'Style','local')

% Allocate auxiliarity arrays for the MUSCL part

% time loop
for n= 1:100000000000000
   sx = Lambdax(Q);
   sy = Lambday(Q);
    max_lx = max(max(max(abs(sx))));
    max_ly = max(max(max(abs(sy))));

    dt = CFL/(max_lx/dx + max_ly/dy); % compute dt form stability condition

    if (t+dt > tend)
        dt = tend -t;
    end
    if (t>= tend)
        break
    end


    % Muscl part

    % space loops
    dtdx = dt/dx;
    dtdy = dt/dy;
    for i = 1:Nx
        for j= 1:Ny
            %xdirection
            if ( i== 1)
            Qghost = [Q(1,i,j); -Q(2,i,j); Q(3,i,j)];
            fm = Rusanovx(Qghost, Q(:,i,j),Lambdax(Qghost),sx(:,i,j));
            fp = Rusanovx(Q(:,i,j), Q(:,i+1,j),sx(:,i,j),sx(:,i+1,j));
            elseif (i==Nx)
            Qghost = [Q(1,i,j); -Q(2,i,j); Q(3,i,j)];
            fm = Rusanovx(Q(:,i-1,j), Q(:,i,j),sx(:,i-1,j),sx(:,i,j));
            fp = Rusanovx(Q(:,i,j), Qghost,sx(:,i,j),Lambdax(Qghost));
            else
            fm = Rusanovx(Q(:,i-1,j), Q(:,i,j),sx(:,i-1,j),sx(:,i,j));
            fp = Rusanovx(Q(:,i,j), Q(:,i+1,j),sx(:,i,j),sx(:,i+1,j));
            end

             %ydirection
               if ( j== 1)
            Qghost = [Q(1,i,j); Q(2,i,j); -Q(3,i,j)];
            gm = Rusanovy(Qghost, Q(:,i,j),Lambday(Qghost),sy(:,i,j));
            gp = Rusanovy(Q(:,i,j), Q(:,i,j+1),sy(:,i,j),sy(:,i,j+1));
            elseif (j==Ny)
            Qghost = [Q(1,i,j); Q(2,i,j); -Q(3,i,j)];
            gm = Rusanovy(Q(:,i,j-1), Q(:,i,j),sy(:,i,j-1),sy(:,i,j));
            gp = Rusanovy(Q(:,i,j),Qghost,sy(:,i,j),Lambday(Qghost));
               else
            gm = Rusanovy(Q(:,i,j-1), Q(:,i,j),sy(:,i,j-1),sy(:,i,j));
            gp = Rusanovy(Q(:,i,j), Q(:,i,j+1),sy(:,i,j),sy(:,i,j+1));
               end

            % Standard Finite-Volume update
            Qnew(:,i,j)= Q(:,i,j) - dtdx*(fp-fm) - dtdy*(gp-gm);
        end
    end

     % update time and solution
     t = t + dt;
     Q = Qnew;

     %plot
    surf(x,y,squeeze(Q(1,:,:))','EdgeColor','none','FaceColor','interp')
    axis([xL xR yL yR 0 3])
    light('Position', [-3 -1 1],'Style','local')
    pause(0.000001)
end


