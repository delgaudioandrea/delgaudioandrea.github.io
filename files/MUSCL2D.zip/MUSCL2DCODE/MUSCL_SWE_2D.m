% MUSCL scheme for the 2D SWE
% with the HLL(Rusanov numerical flux)

clear;
global g h0 Nx Ny x y h hb u v nu Re tend; %blend_factor;
%% Physical parameters
g = 9.81; 
xL = -2; xR = 2;
yL = -0.1; yR = 0.1;
t = 0;
h0= 0.2;
tt= 4;
tend_dimless= 0.7*tt;  %time to add: 0.7 1.4 2.1 2.8 3.5 4.2 4.9 5.6 6.3 7	7.7	8.4	9.1	9.8	10.5 11.2 11.9 12.6	13.3 14
tend = tend_dimless*((h0/9.81)^0.5);
nu = 10^-6;
% Define the small depth threshold for determining dry bed
h_min = 0.000001;  % Threshold for considering the bed as dry



%% Computational paramters
%5000 punti 200 tot
Nx = 20*32;
Ny = 2;
dx = (xR - xL)/Nx;
dy = (yR - yL)/Ny;
x = linspace(xL +dx/2,xR-dx/2,Nx);
y = linspace(yL +dy/2,yR-dy/2,Ny);
CFL = 0.99;

%% initial data
Q = zeros(3,Nx,Ny);
Q = Q0(Q,x,y);
Qnew = Q;
%% topography
% hb = ones(Nx,Ny)*0.0;
% hb(1:end, round(size(hb, 2) / (1.2)):end) = 0.05;
%hb = ones(Nx, Ny).*0.01.*sin(4.*x)+0.01;
%H = Q(1,:,:)+hb(1,:,:);

%% friction
% Water depth and velocities
h = squeeze(Q(1,:,:));  % Water depth
qx = squeeze(Q(2,:,:)); % Momentum in x-direction
qy = squeeze(Q(3,:,:)); % Momentum in y-direction
% Initialize velocities
u = zeros(size(h));
v = zeros(size(h));

% Compute velocities only for cells where h >= h_min
non_dry_mask = (h >= h_min);
u(non_dry_mask) = qx(non_dry_mask) ./ h(non_dry_mask);  % Velocity in x-direction
v(non_dry_mask) = qy(non_dry_mask) ./ h(non_dry_mask);  % Velocity in y-direction
u_mag = sqrt(u.^2 + v.^2); % Velocity magnitude

% Define a small regularization velocity
u_min = 1e-4;  % Small velocity threshold for regularization

% Smooth blending function for the friction coefficient
% This function smoothly blends the friction force to zero as velocity decreases
% alpha = 10;  % Regularization factor that controls smoothness
% blend_factor = 1 - exp(-alpha * u_mag);  % Smooth transition as u_mag -> 0

% Compute the Reynolds number
Re = ones(Nx,Ny);
% Compute the Reynolds number only for non-dry cells
Re(non_dry_mask) = (4*h(non_dry_mask) .* max(u_mag(non_dry_mask), u_min)) / nu;


%% plot
figure
surf(x,y,squeeze(Q(1,:,:))','EdgeColor','none','FaceColor','interp')
axis([xL xR yL yR 0 0.5])
    xlabel('x')
    ylabel('y')
    zlabel('z')
light('Position', [-3 -1 1],'Style','local')

% Allocate auxiliarity arrays for the MUSCL part
Qxm = zeros(3,Nx,Ny);
Qxp = zeros(3,Nx,Ny);
Qym = zeros(3,Nx,Ny);
Qyp = zeros(3,Nx,Ny);
slopex = zeros(3,Nx,Ny);
slopey = zeros(3,Nx,Ny);

% time loop
for n= 1:100000000000000
   sx = Lambdax(Q);
   sy = Lambday(Q);
    max_sx = max(max(max(abs(sx))));
    max_sy = max(max(max(abs(sy))));

    dt = CFL/(max_sx/dx + max_sy/dy); % compute dt form stability condition

    if (t+dt > tend)
        dt = tend -t;
    end
    if (t>= tend)
        break
    end
   deltat(n) = dt; 
   
    %% Muscl part
    % reconstruct the slope and then limit them by calling the minmod
    % limiter function
    slopex(:,2:Nx-1,:) = minmod(Q(:,2:Nx-1,:)-Q(:,1:Nx-2,:), Q(:,3:Nx,:)-Q(:,2:Nx-1,:));
    slopey(:,:,2:Ny-1) = minmod(Q(:,:,2:Ny-1)-Q(:,:,1:Ny-2), Q(:,:,3:Ny)-Q(:,:,2:Ny-1));
    % Extrapolate data towards the cell edges x_{i+1/2] and y_{j+1/2}
    Qxm = Q - 0.5*slopex;
    Qxp = Q + 0.5*slopex;
    Qym = Q - 0.5*slopey;
    Qyp = Q + 0.5*slopey;
    % Compute the time derivative 

    % Friction 
    fr = Friction(Q, x, y);
    % Source term for topography
    %S = Source(Q, x, y);
    
    Qdt_half = Q + 0.5*dt*(Friction(Q, x, y));% + Source(Q, x, y)); 
    fr = Friction(Qdt_half, x, y);
%   S  = Source(Qdt_half, x, y);

    Qt = -( F(Qxp)-F(Qxm))/dx - ( G(Qyp)-G(Qym))/dy + fr;% +S;% source have to be added in this line

    % Extrapolate the data in time to t + dt/2
    Qxm = Qxm + 0.5*dt*Qt;
    Qxp = Qxp + 0.5*dt*Qt;
    Qym = Qym + 0.5*dt*Qt;
    Qyp = Qyp + 0.5*dt*Qt;
   
   %[Qxm, Qxp, Qym, Qyp] = MUSCL(Q, dt,dx,dy);
   % We must update the eigenvalues at the Qxm, Qxp, Qym, Qyp:
   sxm = Lambdax(Qxm);
   sxp = Lambdax(Qxp);
   sym = Lambday(Qym);
   syp = Lambday(Qyp);
   

   
   
    %% Standard part of any Finite Volume method
    % space loops
    dtdx = dt/dx;
    dtdy = dt/dy;
    for i = 1:Nx
        for j= 1:Ny
            %xdirection
            if ( i== 1)
            Qghost = [Qxm(1,i,j); -Qxm(2,i,j); Qxm(3,i,j)];
            fm = Rusanovx(Qghost, Qxm(:,i,j),Lambdax(Qghost),sxm(:,i,j));
            fp = Rusanovx(Qxp(:,i,j), Qxm(:,i+1,j),sxp(:,i,j),sxm(:,i+1,j));
            elseif (i==Nx)
            Qghost = [Qxp(1,i,j); -Qxp(2,i,j); Qxp(3,i,j)];
            fm = Rusanovx(Qxp(:,i-1,j), Qxm(:,i,j),sxp(:,i-1,j),sxm(:,i,j));
            fp = Rusanovx(Qxp(:,i,j), Qghost,sxp(:,i,j),Lambdax(Qghost));
            else
            fm = Rusanovx(Qxp(:,i-1,j), Qxm(:,i,j),sxp(:,i-1,j),sxm(:,i,j));
            fp = Rusanovx(Qxp(:,i,j), Qxm(:,i+1,j),sxp(:,i,j),sxm(:,i+1,j));
            end

             %ydirection
               if ( j== 1)
            Qghost = [Qym(1,i,j); Qym(2,i,j); -Qym(3,i,j)];
            gm = Rusanovy(Qghost, Qym(:,i,j),Lambday(Qghost),sym(:,i,j));
            gp = Rusanovy(Qyp(:,i,j), Qym(:,i,j+1),syp(:,i,j),sym(:,i,j+1));
            elseif (j==Ny)
            Qghost = [Qyp(1,i,j); Qyp(2,i,j); -Qyp(3,i,j)];
            gm = Rusanovy(Qyp(:,i,j-1), Qym(:,i,j),syp(:,i,j-1),sym(:,i,j));
            gp = Rusanovy(Qyp(:,i,j), Qghost,syp(:,i,j),Lambday(Qghost));
            else
            gm = Rusanovy(Qyp(:,i,j-1), Qym(:,i,j),syp(:,i,j-1),sym(:,i,j));
            gp = Rusanovy(Qyp(:,i,j), Qym(:,i,j+1),syp(:,i,j),sym(:,i,j+1));
               end

            
            % Standard Finite-Volume update
            Qnew(:,i,j)= Q(:,i,j) - dtdx*(fp-fm) - dtdy*(gp-gm); %+ dt * fr(:,i,j);% + dt * S(:,i,j);
        end
    end
     %friction factor   
     fr = Friction(Q, x, y);
     Q = Qnew + dt * fr;
     % update time and solution
     t = t + dt;
     t_dimless= t/((h0/9.81)^0.5);
     
     % Water depth and velocities
     h = squeeze(Q(1,:,:));       % Water depth
     qx = squeeze(Q(2,:,:)); % Momentum in x-direction
     qy = squeeze(Q(3,:,:)); % Momentum in y-direction
     % Compute velocities only for cells where h >= h_min
     non_dry_mask = (h >= h_min);
     u(non_dry_mask) = qx(non_dry_mask) ./ h(non_dry_mask);  % Velocity in x-direction
     v(non_dry_mask) = qy(non_dry_mask) ./ h(non_dry_mask);  % Velocity in y-direction
     u_mag = sqrt(u.^2 + v.^2); % Velocity magnitude
     
     H = squeeze(Q(1,:,:));%+hb(:,:);
     x_f = non_dry_mask(1:end-1,1);
     for p = 1:length(non_dry_mask(:,1))-1
     x_f(p,1) = (non_dry_mask(p,1)-non_dry_mask(p+1,1));
     end
     xf(n) = find(x_f);
     xf(n) = x(xf(n)); 
     % Smooth blending function for the friction coefficient
     %blend_factor = 1 - exp(-alpha * u_mag);
     % Compute the Reynolds number
     Re(non_dry_mask) = (4*h(non_dry_mask) .* max(u_mag(non_dry_mask), u_min)) / nu;
     

 %% old plot    
   
%     subplot(3,1,1)
%     surf(x,y,squeeze(Q(1,:,:))','EdgeColor','none','FaceColor','interp')
%     axis([xL xR yL yR 0 0.5])
%     title(strcat('time = ',num2str(t_dimless)))
%     xlabel('x')
%     ylabel('y')
%     zlabel('h')
%     light('Position', [-3 -1 1],'Style','local')
%     pause(0.0001)

    subplot(3,1,1)
    plot(x/h0,-fr(2,:,1),'b')
    title(strcat('time = ',num2str(t_dimless)))
    axis([xL/h0 xR/h0 0 0.06])
    xlabel('x')
    ylabel('C_f [m^2/s^2]')
    pause(0.0001)

    subplot(3,1,2)
    plot(x/h0,H(:,Ny/2)/h0,'b')
    %plot(x,hb(:,Ny/2),'r')
    xlabel('x')
    ylabel('H')
    axis([xL/h0 xR/h0 0 1])
    pause(0.0001)
    hold off

    subplot(3,1,3)
    plot(x/h0,u(:,Ny/2)/(9.81*h0)^0.5,'b')
    xlabel('x')
    ylabel('u')
    axis([xL/h0 xR/h0 0 2])
    pause(0.0001)


 %% plot for comparison
 % plotting part
%     subplot(121)
%     s = surf(x,y,squeeze(Q(1,:,:))','EdgeColor','none','FaceColor','flat');
%    
%     axis( [xL xR yL yR -1  1.25 ] )
%     
%     xlabel('x')
%     ylabel('y')
%     hold off
%     pause(0.0001)
%     
%     subplot(122)
%     plot(x,H(:,Ny/2),'-o')
%     hold on
%     plot(x,hb(:,Ny/2),'r')
%     title(strcat('t = ',num2str(t)))
%     hold off
%     pause(0.0001)
end


%% comparison 
% [X,h_ch] = analitical_chanson;
% subplot(3,1,2)
% hold on
% plot(X,h_ch(20,:),'r')
% legend('MUSC2D','Chanson analitic')
% hold off

% import h freesurf SM-T 0
opts = delimitedTextImportOptions("NumVariables", 56);
opts.DataLines = [1, Inf];
opts.Delimiter = "\t";
opts.VariableNames = ["VarName1", "VarName2", "VarName3", "VarName4", "VarName5", "VarName6", "VarName7", "VarName8", "VarName9", "VarName10", "VarName11", "VarName12", "VarName13", "VarName14", "VarName15", "VarName16", "VarName17", "VarName18", "VarName19", "VarName20", "VarName21", "VarName22", "VarName23", "VarName24", "VarName25", "VarName26", "VarName27", "VarName28", "VarName29", "VarName30", "VarName31", "VarName32", "VarName33", "VarName34", "VarName35", "VarName36", "VarName37", "VarName38", "VarName39", "VarName40", "VarName41", "VarName42", "VarName43", "VarName44", "VarName45", "VarName46", "VarName47", "VarName48", "VarName49", "VarName50", "VarName51", "VarName52", "VarName53", "VarName54", "VarName55", "VarName56"];
opts.VariableTypes = ["double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double"];
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule = "read";
h0SMT = readtable("h0_SM_T.txt", opts);
h0SMT = table2array(h0SMT);
clear opts
% import fr freesurf SM-T 0
opts = delimitedTextImportOptions("NumVariables", 56);
opts.DataLines = [1, Inf];
opts.Delimiter = "\t";
opts.VariableNames = ["VarName1", "NaN", "VarName3", "NaN_1", "VarName5", "NaN_2", "VarName7", "NaN_3", "VarName9", "NaN_4", "VarName11", "NaN_5", "VarName13", "NaN_6", "VarName15", "NaN_7", "VarName17", "NaN_8", "VarName19", "NaN_9", "VarName21", "NaN_10", "VarName23", "NaN_11", "VarName25", "NaN_12", "VarName27", "NaN_13", "VarName29", "NaN_14", "VarName31", "NaN_15", "VarName33", "NaN_16", "VarName35", "NaN_17", "VarName37", "NaN_18", "VarName39", "NaN_19", "VarName41", "NaN_20", "VarName43", "NaN_21", "VarName45", "NaN_22", "VarName47", "NaN_23", "VarName49", "NaN_24", "VarName51", "NaN_25", "VarName53", "NaN_26", "VarName55", "NaN_27"];
opts.VariableTypes = ["double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double"];
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule = "read";
fr0SMT = readtable("fr0_SM_T.txt", opts);
fr0SMT = table2array(fr0SMT);
clear opts
% import u velocity u-SM-T 0
opts = delimitedTextImportOptions("NumVariables", 56);
opts.DataLines = [1, Inf];
opts.Delimiter = "\t";
opts.VariableNames = ["VarName1", "NaN", "VarName3", "NaN_1", "VarName5", "NaN_2", "VarName7", "NaN_3", "VarName9", "NaN_4", "VarName11", "NaN_5", "VarName13", "NaN_6", "VarName15", "NaN_7", "VarName17", "NaN_8", "VarName19", "NaN_9", "VarName21", "NaN_10", "VarName23", "NaN_11", "VarName25", "NaN_12", "VarName27", "NaN_13", "VarName29", "NaN_14", "VarName31", "NaN_15", "VarName33", "NaN_16", "VarName35", "NaN_17", "VarName37", "NaN_18", "VarName39", "NaN_19", "VarName41", "NaN_20", "VarName43", "NaN_21", "VarName45", "NaN_22", "VarName47", "NaN_23", "VarName49", "NaN_24", "VarName51", "NaN_25", "VarName53", "NaN_26", "VarName55", "NaN_27"];
opts.VariableTypes = ["double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double", "double"];
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule = "read";
u0SMT = readtable("u0_SM_T.txt", opts);
u0SMT = table2array(u0SMT);
clear opts


i= (tend_dimless)/0.7;
subplot(3,1,2)
hold on
plot(h0SMT(:,2*i-1),h0SMT(:,2*i),'r')
legend('MUSC2D','SM-T0')
hold off

subplot(3,1,1)
hold on
plot(fr0SMT(:,2*i-1),fr0SMT(:,2*i),'r')
legend('MUSC2D','SM-T0')
hold off

subplot(3,1,3)
hold on
plot(u0SMT(:,2*i-1),u0SMT(:,2*i),'r')
legend('MUSC2D','SM-T0')
hold off

%% export front
t_f =zeros(1,length(deltat)+1);
X_f =zeros(1,length(xf)+1); 
X_f(2:end) = xf;
for p= 1:length(deltat)
t_f(p+1) = t_f(p)+deltat(p);
end

front= [t_f/((h0/9.81)^0.5);X_f/h0];
% writematrix(,'M_tab.txt','Delimiter','tab')