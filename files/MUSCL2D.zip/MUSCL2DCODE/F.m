% Physical fluxes for the 2D SWE in the X direction
function flux_x = F(Q)
global g
flux_x = zeros(size(Q));
flux_x(1,:,:) = Q(2,:,:);
flux_x(2,:,:) = Q(2,:,:).^2./Q(1,:,:)+0.5*g*Q(1,:,:).^2;
flux_x(3,:,:) = Q(2,:,:).*Q(3,:,:)./Q(1,:,:);
end
